from cdb.comparch.pkgtools import setup

setup(
    name="tickets.plm",
    version="1.0.0",
    install_requires=['cs.platform', 'cs.docportal', 'cs.licreport', 'cs.migration', 'cs.powerscriptstudio', 'cs.web', 'cs.base', 'cs.designsystem', 'cs.licdashboard', 'cs.activitystream', 'cs.baselining', 'cs.cadbase', 'cs.launchpad', 'cs.officelink', 'cs.taskboard', 'cs.admin', 'cs.powerreports', 'cs.taskmanager', 'cs.erp', 'cs.workflow', 'cs.actions', 'cs.xml', 'cs.documents', 'cs.metrics', 'cs.psi', 'cs.classification', 'cs.defects', 'cs.fileclient', 'cs.portfolios', 'cs.materials', 'cs.pcs', 'cs.vp', 'cs.bomcreator', 'cs.ec', 'cs.threed', 'cs.vp-pcs', 'cs.workspaces-server', 'cs.variants', 'cs.workspaces', 'cs.catia', 'cs.eplan-server', 'cs.solidworks', 'cs.eplan', 'cscdb.product'],
    docsets=[
        # Add a relative path for each documentation set in this package
        ],
    cdb_modules=[
        # List the package's modules in the correct (initialization) order as
        # computed by cdb.comparch topological sort. This list goes into
        # `cdb_modules.txt` in the EGG-INFO.
        "tickets.plm"
        ],
    cdb_services=[
        # List the services of this packages by their class names. This list
        # goes into `cdb_services.txt` in EGG-INFO.
        ],
)
