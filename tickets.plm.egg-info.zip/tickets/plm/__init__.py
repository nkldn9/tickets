#!/usr/bin/env powerscript
# -*- mode: python; coding: utf-8 -*-

from cdb import platform
from cdb.objects import Object


class ClassificationTypes(Object):

    __classname__ = 'classification_types'
    __maps_to__ = 'classification_types'

class ClassificationCatalog(platform.gui.CDBCatalog):
    def __init__(self):
        platform.gui.CDBCatalog.__init__(self)

    def handlesSimpleCatalog(self):
        return True

    def getCatalogEntries(self):
        return ["Bug","Feature","Technical Debt"]

class Severity(Object):
    __classname__= 'Severity'
    __maps_to__ = 'Severity'
