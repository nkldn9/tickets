#!/usr/bin/env powerscript
# -*- mode: python; coding: utf-8 -*-

from cdb.objects import Object, State, Transition, Reference_1, Reference_N, ReferenceMethods_N, Forward
from cdb.objects.org import Person, Organization
from cdb import util,auth,ue,sqlapi
from cs.documents import Document
from cs.vp.products import Product

import datetime

# forward declarations
fChangeRequest = Forward(__name__ + ".ChangeRequest")


class ChangeRequest(Object):
    
    __classname__ = 'change_request'
    __maps_to__ = 'change_request'
    
    event_map = {
        ('create','pre_mask'):('genCRID','reportedByOn'),
        ('*','button_pressed'):"_handle_button_pressed",
        ('modify','pre_mask'):('genCRID','checkStatus'),
        ('modify','now'):('setCriticalSeverity','quickClose'),
        ('modify','state_change'):('checkDescription','on_cr_close_changerequest_now'),
    }
    


    def genCRID(self,ctx):
        if self.classification and self.id == '#':
            initial = self.classification[0]
            counter_name =  initial + "_counter"
            id_val = "%s%06d" %(initial,util.nextval(counter_name))   
        elif not self.classification:
            id_val = '#'
        else:
            id_val = self.id
        
        ctx.set('id',id_val)

        
        
    def reportedByOn(self,ctx):
        ctx.set('reported_by',auth.get_name())
        ctx.set('reported_on',datetime.date.today())

    
    def checkStatus(self,ctx):
        if self.cdb_status_txt == 'Accept' or self.cdb_status_txt == 'Testing' :
            ctx.set_writeable('solution4_txt.solution4_txt')
        else:
            ctx.set_readonly('solution4_txt.solution4_txt')
        
            
    def _handle_button_pressed(self,ctx):
        if ctx.button_pressed == 'button_fmt': 
            ctx.set('fixed_by',auth.get_name())
            ctx.set('fixed_on',datetime.date.today())
    
    def setCriticalSeverity(self,ctx):
        rset = sqlapi.RecordSet2("Severity","ranking = '0'")
        critical_severity = rset[0]
        self.severity = critical_severity.severity_name
        self.severity_ranking = critical_severity.ranking
        #ctx.set('severity',)
        #ctx.set('severity_ranking',)
        ctx.set('description4_txt.description4_txt','- HIGH PRIORITY -\n' + ctx.getValue('description4_txt.description4_txt'))
        
    def checkDescription(self,ctx):
        if self.description4_txt.description4_txt == '':
            raise ue.Exception('cdbwf_task_mandatory_field')

    @classmethod
    def quickClose(cls,ctx):
        for obj in cls.PersistentObjectsFromContext(ctx):
            obj.benennung = ctx.dialog.benennung
        
        if ctx.get(['solution4_txt']) != '': 
            ctx.set('status',200)
            ctx.set('cdb_status_txt','Closed')
        else:
            raise ue.Exception('Solution is not added. Cannot close this request.')

    def on_cr_close_changerequest_now(self,ctx):
        if ctx.get(['solution4_txt']) != '': 
            ctx.set('status',200)
            ctx.set('cdb_status_txt','Closed')
        else:
            raise ue.Exception('Solution is not added. Cannot close this request.')
        
    
    # CR to Documents
    AllCRToDocs = Reference_N(Document, Document.cdb_object_id == fChangeRequest.cdb_object_id)
    def _Documents(self):
        return [link.Document for link in self.AllCRToDocs]
    
    Documents = ReferenceMethods_N(Document, _Documents)

    
    # CR to Responsible
    AllCRToResp = Reference_N(Person, Person.cdb_object_id == fChangeRequest.cdb_object_id)
    def _Person(self):
        return [link.Person for link in self.AllCRToResp]
    
    Persons = ReferenceMethods_N(Person, _Person)
    
    # CR to Products
    AllCRToProduct = Reference_N(Product, Product.cdb_object_id == fChangeRequest.cdb_object_id)
    def _Product(self):
        return [link.Product for link in self.AllCRToProduct]
    
    Products = ReferenceMethods_N(Product, _Product)
    
    # CR to Customers
    AllCRToCust = Reference_N(Organization, Organization.cdb_object_id == fChangeRequest.cdb_object_id)
    def _Customer(self):
        return [link.Organization for link in self.AllCRToCust]
    
    Customers = ReferenceMethods_N(Organization, _Customer)

    # States
    
    class INREVIEW(State):
        status = 50
        
        def pre(state, self, ctx):
            pass

        def post(state, self, ctx):
            pass
            
    class ACCEPT(State):
        status = 100
        
        def pre(state, self, ctx):
            pass

        def post(state, self, ctx):
            ctx.set('change_number', 'state changed')
            
    class TESTING(State):
        status = 150
        
        def pre(state, self, ctx):
            pass

        def post(state, self, ctx):
            pass
            
    class CLOSED(State):
        status = 200
        
        def pre(state, self, ctx):
            pass

        def post(state, self, ctx):
            pass
    
    # Transitions 
    
    class INREVIEW_TO_ACCEPT(Transition):
        transition = (50 , 100) # or ‘*’ for any
        
        def pre(transition, self, ctx):
            pass

        def post(transition, self, ctx):
            pass
    
    class ACCPET_TO_TESTING(Transition):
        transition = (100 , 150) # or ‘*’ for any
        
        def pre(transition, self, ctx):
            pass

        def post(transition, self, ctx):
            pass
            
    class TESTING_TO_CLOSED(Transition):
        transition = (150 , 200) # or ‘*’ for any
        
        def pre(transition, self, ctx):
            pass

        def post(transition, self, ctx):
            pass
            
    
